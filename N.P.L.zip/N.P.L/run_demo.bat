@echo off
setlocal
set "PYTHONPATH=%~dp0"
if "%~1"=="" (
    python -m pulse.cli.main run "%~dp0examples\mvp_demo.pulse"
) else (
    python -m pulse.cli.main run "%~1"
)
echo.
pause
endlocal
