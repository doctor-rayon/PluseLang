@echo off
setlocal
set "PYTHONPATH=%~dp0"
python -m pulse.cli.main %*
endlocal
