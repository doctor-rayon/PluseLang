import unittest
from pulse.lexer.lexer import Lexer
from pulse.parser.parser import Parser
from pulse.ir.builder import IRBuilder
from pulse.compiler.optimizer import Optimizer
from pulse.compiler.serializer import BytecodeSerializer, MAGIC


class TestCompilerSerializer(unittest.TestCase):
    def test_serialization_roundtrip(self):
        source = """
        let x = 10 + 20
        state score = 0
        watch score {
            when score >= 100 => print("Winner")
        }
        score = 100
        """
        tokens = Lexer(source).tokenize()
        ast = Parser(tokens).parse()
        ir_program = IRBuilder().build(ast)
        opt_ir = Optimizer().optimize(ir_program)

        serializer = BytecodeSerializer()
        compiled = serializer.compile_ir(opt_ir)

        binary_data = serializer.serialize(compiled)
        self.assertTrue(binary_data.startswith(MAGIC))

        restored = serializer.deserialize(binary_data)
        self.assertEqual(restored.strings, compiled.strings)
        self.assertEqual(restored.state_vars, compiled.state_vars)
        self.assertEqual(len(restored.watchers), len(compiled.watchers))
        self.assertEqual(restored.code, compiled.code)


if __name__ == "__main__":
    unittest.main()
