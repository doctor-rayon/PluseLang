import io
import unittest
from pulse.lexer.lexer import Lexer
from pulse.parser.parser import Parser
from pulse.semantic.analyzer import SemanticAnalyzer
from pulse.runtime.interpreter import Interpreter
from pulse.runtime.reactive_engine import ReactiveCycleError


class TestRuntime(unittest.TestCase):
    def run_pulse(self, source: str) -> str:
        tokens = Lexer(source).tokenize()
        ast = Parser(tokens).parse()
        SemanticAnalyzer().analyze(ast)

        buf = io.StringIO()
        interpreter = Interpreter(output_stream=buf)
        interpreter.interpret(ast)
        return buf.getvalue().strip()

    def test_mvp_execution(self):
        source = """
        let x = 10
        let y = 20
        print(x + y)

        state score = 0
        watch score {
            when score >= 100 => print("Winner")
        }

        score = 100
        """
        output = self.run_pulse(source)
        self.assertEqual(output, "30\nWinner")

    def test_multiple_when_triggers(self):
        source = """
        state health = 100
        watch health {
            when health <= 50 => print("Warning: Low Health")
            when health <= 0  => print("Game Over")
        }

        health = 40
        health = 0
        """
        output = self.run_pulse(source)
        self.assertEqual(output, "Warning: Low Health\nWarning: Low Health\nGame Over")

    def test_cycle_detection(self):
        source = """
        state loop_var = 0
        watch loop_var {
            when loop_var >= 0 => loop_var = loop_var + 1
        }
        loop_var = 1
        """
        tokens = Lexer(source).tokenize()
        ast = Parser(tokens).parse()
        SemanticAnalyzer().analyze(ast)
        interpreter = Interpreter()

        with self.assertRaises(ReactiveCycleError):
            interpreter.interpret(ast)


if __name__ == "__main__":
    unittest.main()
