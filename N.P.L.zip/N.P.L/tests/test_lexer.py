import unittest
from pulse.lexer.lexer import Lexer, LexerError
from pulse.lexer.token import TokenType


class TestLexer(unittest.TestCase):
    def test_basic_tokens(self):
        source = "let score = 100 state health = 50.5"
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        expected_types = [
            TokenType.LET, TokenType.IDENTIFIER, TokenType.EQUAL, TokenType.NUMBER,
            TokenType.STATE, TokenType.IDENTIFIER, TokenType.EQUAL, TokenType.NUMBER,
            TokenType.EOF
        ]

        self.assertEqual([t.type for t in tokens], expected_types)
        self.assertEqual(tokens[1].lexeme, "score")
        self.assertEqual(tokens[3].value, 100)
        self.assertEqual(tokens[7].value, 50.5)

    def test_watch_when_tokens(self):
        source = "watch score { when score >= 100 => print(\"Win\") }"
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        expected_types = [
            TokenType.WATCH, TokenType.IDENTIFIER, TokenType.LBRACE,
            TokenType.WHEN, TokenType.IDENTIFIER, TokenType.GTE, TokenType.NUMBER,
            TokenType.FAT_ARROW, TokenType.PRINT, TokenType.LPAREN, TokenType.STRING,
            TokenType.RPAREN, TokenType.RBRACE, TokenType.EOF
        ]
        self.assertEqual([t.type for t in tokens], expected_types)

    def test_lexer_error(self):
        source = "let x = & 10"
        lexer = Lexer(source)
        with self.assertRaises(LexerError):
            lexer.tokenize()


if __name__ == "__main__":
    unittest.main()
