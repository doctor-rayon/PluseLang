import io
import unittest
from pulse.lexer.lexer import Lexer
from pulse.parser.parser import Parser
from pulse.semantic.analyzer import SemanticAnalyzer
from pulse.ir.builder import IRBuilder
from pulse.compiler.optimizer import Optimizer
from pulse.compiler.serializer import BytecodeSerializer
from pulse.vm.vm import PulseVM
from pulse.runtime.reactive_engine import ReactiveCycleError


class TestPulseVM(unittest.TestCase):
    def compile_and_run(self, source: str) -> str:
        tokens = Lexer(source).tokenize()
        ast = Parser(tokens).parse()
        SemanticAnalyzer().analyze(ast)

        ir_program = IRBuilder().build(ast)
        opt_ir = Optimizer().optimize(ir_program)

        serializer = BytecodeSerializer()
        compiled = serializer.compile_ir(opt_ir)

        buf = io.StringIO()
        vm = PulseVM(output_stream=buf)
        vm.run(compiled)
        return buf.getvalue().strip()

    def test_mvp_execution_in_vm(self):
        source = """
        let x = 10
        let y = 20
        print(x + y)

        state score = 0
        watch score {
            when score >= 100 => print("Winner")
        }

        score = 100
        """
        output = self.compile_and_run(source)
        self.assertEqual(output, "30\nWinner")

    def test_multiple_when_triggers_in_vm(self):
        source = """
        state health = 100
        watch health {
            when health <= 50 => print("Warning: Low Health")
            when health <= 0  => print("Game Over")
        }

        health = 40
        health = 0
        """
        output = self.compile_and_run(source)
        self.assertEqual(output, "Warning: Low Health\nWarning: Low Health\nGame Over")

    def test_vm_cycle_detection(self):
        source = """
        state loop_var = 0
        watch loop_var {
            when loop_var >= 0 => loop_var = loop_var + 1
        }
        loop_var = 1
        """
        tokens = Lexer(source).tokenize()
        ast = Parser(tokens).parse()
        SemanticAnalyzer().analyze(ast)
        ir_prog = IRBuilder().build(ast)
        compiled = BytecodeSerializer().compile_ir(ir_prog)

        vm = PulseVM()
        with self.assertRaises(ReactiveCycleError):
            vm.run(compiled)


if __name__ == "__main__":
    unittest.main()
