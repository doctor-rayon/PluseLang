import unittest
from pulse.lexer.lexer import Lexer
from pulse.parser.parser import Parser
from pulse.ir.builder import IRBuilder
from pulse.ir.instructions import IROp


class TestIR(unittest.TestCase):
    def test_ir_generation(self):
        source = """
        let x = 10
        let y = 20
        print(x + y)

        state score = 0
        watch score {
            when score >= 100 => print("Winner")
        }
        score = 100
        """
        tokens = Lexer(source).tokenize()
        ast = Parser(tokens).parse()
        ir_program = IRBuilder().build(ast)

        self.assertIn("score", ir_program.state_variables)
        self.assertEqual(len(ir_program.watchers), 1)

        ops = [i.op for i in ir_program.instructions]
        self.assertIn(IROp.STORE_VAR, ops)
        self.assertIn(IROp.STATE_CREATE, ops)
        self.assertIn(IROp.STATE_SET, ops)
        self.assertIn(IROp.WATCH_CREATE, ops)
        self.assertIn(IROp.PRINT, ops)
        self.assertIn(IROp.HALT, ops)


if __name__ == "__main__":
    unittest.main()
