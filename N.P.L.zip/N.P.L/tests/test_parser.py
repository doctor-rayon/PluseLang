import unittest
from pulse.lexer.lexer import Lexer
from pulse.parser.parser import Parser
from pulse.parser.ast import ProgramNode, VarDeclNode, StateDeclNode, WatchNode, PrintStmtNode


class TestParser(unittest.TestCase):
    def test_parse_declarations(self):
        source = "let x = 10\nstate score = 0"
        tokens = Lexer(source).tokenize()
        ast = Parser(tokens).parse()

        self.assertIsInstance(ast, ProgramNode)
        self.assertEqual(len(ast.statements), 2)
        self.assertIsInstance(ast.statements[0], VarDeclNode)
        self.assertEqual(ast.statements[0].name, "x")
        self.assertIsInstance(ast.statements[1], StateDeclNode)
        self.assertEqual(ast.statements[1].name, "score")

    def test_parse_watch_when(self):
        source = """
        state score = 0
        watch score {
            when score >= 100 => print("Winner")
        }
        """
        tokens = Lexer(source).tokenize()
        ast = Parser(tokens).parse()

        self.assertEqual(len(ast.statements), 2)
        self.assertIsInstance(ast.statements[1], WatchNode)
        watch_node = ast.statements[1]
        self.assertEqual(watch_node.target_name, "score")
        self.assertEqual(len(watch_node.when_clauses), 1)
        self.assertIsInstance(watch_node.when_clauses[0].body, PrintStmtNode)


if __name__ == "__main__":
    unittest.main()
