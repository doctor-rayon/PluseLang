import unittest
from pulse.lexer.lexer import Lexer
from pulse.parser.parser import Parser
from pulse.semantic.analyzer import SemanticAnalyzer, SemanticError


class TestSemanticAnalyzer(unittest.TestCase):
    def test_valid_program(self):
        source = """
        let x = 10
        state score = 0
        watch score {
            when score >= 100 => print("Win")
        }
        """
        tokens = Lexer(source).tokenize()
        ast = Parser(tokens).parse()
        analyzer = SemanticAnalyzer()
        # Should complete without error
        analyzer.analyze(ast)

    def test_watching_non_state_variable(self):
        source = """
        let score = 0
        watch score {
            when score >= 100 => print("Win")
        }
        """
        tokens = Lexer(source).tokenize()
        ast = Parser(tokens).parse()
        analyzer = SemanticAnalyzer()
        with self.assertRaises(SemanticError) as ctx:
            analyzer.analyze(ast)
        self.assertIn("Only 'state' variables can be watched", str(ctx.exception))

    def test_undefined_variable(self):
        source = "print(undefined_var)"
        tokens = Lexer(source).tokenize()
        ast = Parser(tokens).parse()
        analyzer = SemanticAnalyzer()
        with self.assertRaises(SemanticError) as ctx:
            analyzer.analyze(ast)
        self.assertIn("Variable 'undefined_var' is not defined", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
