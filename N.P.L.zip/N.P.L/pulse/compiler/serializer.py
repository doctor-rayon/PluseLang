import struct
from typing import List, Dict, Tuple, Any, Optional
from pulse.ir.instructions import IROp, IRInstruction, IRProgram, IRWatcherBlock
from pulse.vm.opcodes import OpCode

MAGIC = b"PULSEC"
VERSION = 1
TARGET_VM = 0

# Constant Tags
TAG_NULL = 0
TAG_INT = 1
TAG_FLOAT = 2
TAG_STRING = 3
TAG_BOOL = 4


class CompiledBytecode:
    def __init__(self, constants: List[Any], strings: List[str], state_vars: List[str],
                 watchers: List[Dict[str, Any]], code: bytes, debug_map: Dict[int, Tuple[int, int]]):
        self.constants = constants
        self.strings = strings
        self.state_vars = state_vars
        self.watchers = watchers  # List of {'target_name_idx', 'condition_code', 'body_code'}
        self.code = code
        self.debug_map = debug_map  # byte_offset -> (line, col)


class BytecodeSerializer:
    def compile_ir(self, program: IRProgram) -> CompiledBytecode:
        constants: List[Any] = []
        strings: List[str] = []
        string_indices: Dict[str, int] = {}
        const_indices: Dict[Tuple[type, Any], int] = {}

        def get_string_idx(s: str) -> int:
            if s not in string_indices:
                string_indices[s] = len(strings)
                strings.append(s)
            return string_indices[s]

        def get_const_idx(c: Any) -> int:
            key = (type(c), c)
            if key not in const_indices:
                const_indices[key] = len(constants)
                constants.append(c)
                if isinstance(c, str):
                    get_string_idx(c)
            return const_indices[key]

        # Register state variables in string table
        state_var_indices = [get_string_idx(name) for name in program.state_variables]

        # Compile instructions to bytecode
        main_code, debug_map = self._emit_instructions(program.instructions, get_const_idx, get_string_idx)

        # Compile watcher blocks
        compiled_watchers = []
        for w in program.watchers:
            cond_code, _ = self._emit_instructions(w.condition_instructions, get_const_idx, get_string_idx)
            body_code, _ = self._emit_instructions(w.body_instructions, get_const_idx, get_string_idx)
            compiled_watchers.append({
                "target_name_idx": get_string_idx(w.target_name),
                "condition_code": cond_code,
                "body_code": body_code
            })

        return CompiledBytecode(
            constants=constants,
            strings=strings,
            state_vars=program.state_variables,
            watchers=compiled_watchers,
            code=main_code,
            debug_map=debug_map
        )

    def _emit_instructions(self, instructions: List[IRInstruction], get_const_idx, get_string_idx) -> Tuple[bytes, Dict[int, Tuple[int, int]]]:
        # First pass: label offsets resolution
        labels: Dict[str, int] = {}
        byte_offset = 0

        for instr in instructions:
            if instr.op == IROp.LABEL:
                labels[instr.arg] = byte_offset
            else:
                byte_offset += self._instruction_size(instr)

        # Second pass: emit bytecode bytes and debug map
        code = bytearray()
        debug_map: Dict[int, Tuple[int, int]] = {}

        for instr in instructions:
            if instr.op == IROp.LABEL:
                continue

            current_offset = len(code)
            debug_map[current_offset] = (instr.line, instr.column)

            if instr.op == IROp.CONST:
                idx = get_const_idx(instr.arg)
                code.append(OpCode.PUSH_CONST)
                code.extend(struct.pack(">H", idx))

            elif instr.op == IROp.LOAD_VAR:
                idx = get_string_idx(instr.arg)
                code.append(OpCode.LOAD_VAR)
                code.extend(struct.pack(">H", idx))

            elif instr.op == IROp.STORE_VAR:
                idx = get_string_idx(instr.arg)
                code.append(OpCode.STORE_VAR)
                code.extend(struct.pack(">H", idx))

            elif instr.op == IROp.STATE_CREATE:
                idx = get_string_idx(instr.arg)
                code.append(OpCode.STATE_CREATE)
                code.extend(struct.pack(">H", idx))

            elif instr.op == IROp.STATE_GET:
                idx = get_string_idx(instr.arg)
                code.append(OpCode.STATE_GET)
                code.extend(struct.pack(">H", idx))

            elif instr.op == IROp.STATE_SET:
                idx = get_string_idx(instr.arg)
                code.append(OpCode.STATE_SET)
                code.extend(struct.pack(">H", idx))

            elif instr.op == IROp.WATCH_CREATE:
                state_name, watcher_id = instr.arg
                state_idx = get_string_idx(state_name)
                watcher_idx = int(watcher_id.split("_")[-1]) - 1 if "_" in watcher_id else 0
                code.append(OpCode.WATCH_CREATE)
                code.extend(struct.pack(">HH", state_idx, watcher_idx))

            elif instr.op == IROp.BINARY_OP:
                op_map = {
                    '+': OpCode.ADD, '-': OpCode.SUB, '*': OpCode.MUL, '/': OpCode.DIV, '%': OpCode.MOD,
                    '==': OpCode.EQ, '!=': OpCode.NEQ, '>': OpCode.GT, '>=': OpCode.GTE,
                    '<': OpCode.LT, '<=': OpCode.LTE, '&&': OpCode.AND, '||': OpCode.OR
                }
                code.append(op_map[instr.arg])

            elif instr.op == IROp.UNARY_OP:
                op_map = {'!': OpCode.NOT, '-': OpCode.NEG}
                code.append(op_map[instr.arg])

            elif instr.op == IROp.JUMP:
                target_offset = labels.get(instr.arg, 0)
                code.append(OpCode.JUMP)
                code.extend(struct.pack(">I", target_offset))

            elif instr.op == IROp.JUMP_IF_FALSE:
                target_offset = labels.get(instr.arg, 0)
                code.append(OpCode.JUMP_IF_FALSE)
                code.extend(struct.pack(">I", target_offset))

            elif instr.op == IROp.PRINT:
                code.append(OpCode.PRINT)

            elif instr.op == IROp.HALT:
                code.append(OpCode.HALT)

        return bytes(code), debug_map

    @staticmethod
    def _instruction_size(instr: IRInstruction) -> int:
        if instr.op in (IROp.CONST, IROp.LOAD_VAR, IROp.STORE_VAR, IROp.STATE_CREATE, IROp.STATE_GET, IROp.STATE_SET):
            return 3
        if instr.op == IROp.WATCH_CREATE:
            return 5
        if instr.op in (IROp.JUMP, IROp.JUMP_IF_FALSE):
            return 5
        return 1

    def serialize(self, compiled: CompiledBytecode) -> bytes:
        out = bytearray()
        out.extend(MAGIC)
        out.extend(struct.pack(">HH", VERSION, TARGET_VM))

        # 1. String table
        out.extend(struct.pack(">H", len(compiled.strings)))
        for s in compiled.strings:
            s_bytes = s.encode("utf-8")
            out.extend(struct.pack(">H", len(s_bytes)))
            out.extend(s_bytes)

        # 2. Constant table
        out.extend(struct.pack(">H", len(compiled.constants)))
        for c in compiled.constants:
            if c is None:
                out.append(TAG_NULL)
            elif isinstance(c, bool):
                out.append(TAG_BOOL)
                out.append(1 if c else 0)
            elif isinstance(c, int):
                out.append(TAG_INT)
                out.extend(struct.pack(">q", c))
            elif isinstance(c, float):
                out.append(TAG_FLOAT)
                out.extend(struct.pack(">d", c))
            elif isinstance(c, str):
                out.append(TAG_STRING)
                s_bytes = c.encode("utf-8")
                out.extend(struct.pack(">H", len(s_bytes)))
                out.extend(s_bytes)

        # 3. State Variables
        out.extend(struct.pack(">H", len(compiled.state_vars)))
        for sv in compiled.state_vars:
            s_bytes = sv.encode("utf-8")
            out.extend(struct.pack(">H", len(s_bytes)))
            out.extend(s_bytes)

        # 4. Watcher Registry
        out.extend(struct.pack(">H", len(compiled.watchers)))
        for w in compiled.watchers:
            out.extend(struct.pack(">H", w["target_name_idx"]))
            out.extend(struct.pack(">I", len(w["condition_code"])))
            out.extend(w["condition_code"])
            out.extend(struct.pack(">I", len(w["body_code"])))
            out.extend(w["body_code"])

        # 5. Main Code Section
        out.extend(struct.pack(">I", len(compiled.code)))
        out.extend(compiled.code)

        # 6. Debug Map
        out.extend(struct.pack(">I", len(compiled.debug_map)))
        for offset, (line, col) in compiled.debug_map.items():
            out.extend(struct.pack(">III", offset, line, col))

        return bytes(out)

    def deserialize(self, data: bytes) -> CompiledBytecode:
        if len(data) < 10 or data[:6] != MAGIC:
            raise ValueError("Invalid .pulsec binary format or header mismatch.")

        offset = 6
        version, target = struct.unpack_from(">HH", data, offset)
        offset += 4

        if version != VERSION:
            raise ValueError(f"Unsupported .pulsec version {version}.")

        # 1. Read String Table
        num_strings = struct.unpack_from(">H", data, offset)[0]
        offset += 2
        strings: List[str] = []
        for _ in range(num_strings):
            s_len = struct.unpack_from(">H", data, offset)[0]
            offset += 2
            s_bytes = data[offset:offset + s_len]
            strings.append(s_bytes.decode("utf-8"))
            offset += s_len

        # 2. Read Constant Table
        num_consts = struct.unpack_from(">H", data, offset)[0]
        offset += 2
        constants: List[Any] = []
        for _ in range(num_consts):
            tag = data[offset]
            offset += 1
            if tag == TAG_NULL:
                constants.append(None)
            elif tag == TAG_BOOL:
                constants.append(data[offset] != 0)
                offset += 1
            elif tag == TAG_INT:
                val = struct.unpack_from(">q", data, offset)[0]
                constants.append(val)
                offset += 8
            elif tag == TAG_FLOAT:
                val = struct.unpack_from(">d", data, offset)[0]
                constants.append(val)
                offset += 8
            elif tag == TAG_STRING:
                s_len = struct.unpack_from(">H", data, offset)[0]
                offset += 2
                constants.append(data[offset:offset + s_len].decode("utf-8"))
                offset += s_len

        # 3. Read State Variables
        num_states = struct.unpack_from(">H", data, offset)[0]
        offset += 2
        state_vars: List[str] = []
        for _ in range(num_states):
            s_len = struct.unpack_from(">H", data, offset)[0]
            offset += 2
            state_vars.append(data[offset:offset + s_len].decode("utf-8"))
            offset += s_len

        # 4. Read Watchers
        num_watchers = struct.unpack_from(">H", data, offset)[0]
        offset += 2
        watchers: List[Dict[str, Any]] = []
        for _ in range(num_watchers):
            target_idx = struct.unpack_from(">H", data, offset)[0]
            offset += 2
            cond_len = struct.unpack_from(">I", data, offset)[0]
            offset += 4
            cond_code = data[offset:offset + cond_len]
            offset += cond_len
            body_len = struct.unpack_from(">I", data, offset)[0]
            offset += 4
            body_code = data[offset:offset + body_len]
            offset += body_len
            watchers.append({
                "target_name_idx": target_idx,
                "condition_code": cond_code,
                "body_code": body_code
            })

        # 5. Read Code Section
        code_len = struct.unpack_from(">I", data, offset)[0]
        offset += 4
        code = data[offset:offset + code_len]
        offset += code_len

        # 6. Read Debug Map
        num_debug = struct.unpack_from(">I", data, offset)[0]
        offset += 4
        debug_map: Dict[int, Tuple[int, int]] = {}
        for _ in range(num_debug):
            b_off, line, col = struct.unpack_from(">III", data, offset)
            debug_map[b_off] = (line, col)
            offset += 12

        return CompiledBytecode(
            constants=constants,
            strings=strings,
            state_vars=state_vars,
            watchers=watchers,
            code=code,
            debug_map=debug_map
        )
