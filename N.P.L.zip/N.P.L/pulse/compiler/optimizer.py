from typing import List
from pulse.ir.instructions import IROp, IRInstruction, IRProgram, IRWatcherBlock


class Optimizer:
    def optimize(self, program: IRProgram) -> IRProgram:
        optimized_instructions = self._fold_constants(program.instructions)

        optimized_watchers: List[IRWatcherBlock] = []
        for w in program.watchers:
            opt_cond = self._fold_constants(w.condition_instructions)
            opt_body = self._fold_constants(w.body_instructions)
            optimized_watchers.append(IRWatcherBlock(
                id=w.id,
                target_name=w.target_name,
                condition_instructions=opt_cond,
                body_instructions=opt_body
            ))

        return IRProgram(
            instructions=optimized_instructions,
            state_variables=program.state_variables,
            watchers=optimized_watchers
        )

    def _fold_constants(self, instructions: List[IRInstruction]) -> List[IRInstruction]:
        result: List[IRInstruction] = []
        i = 0
        while i < len(instructions):
            if i + 2 < len(instructions):
                i0 = instructions[i]
                i1 = instructions[i + 1]
                i2 = instructions[i + 2]

                if i0.op == IROp.CONST and i1.op == IROp.CONST and i2.op == IROp.BINARY_OP:
                    val0 = i0.arg
                    val1 = i1.arg
                    op = i2.arg
                    folded_val = self._eval_const_binary(val0, val1, op)
                    if folded_val is not None:
                        result.append(IRInstruction(op=IROp.CONST, arg=folded_val, line=i0.line, column=i0.column))
                        i += 3
                        continue

            result.append(instructions[i])
            i += 1
        return result

    @staticmethod
    def _eval_const_binary(left: any, right: any, op: str) -> any:
        try:
            if op == '+':
                if isinstance(left, (int, float, str)) and isinstance(right, (int, float, str)):
                    if isinstance(left, str) or isinstance(right, str):
                        return str(left) + str(right)
                    return left + right
            elif op == '-':
                if isinstance(left, (int, float)) and isinstance(right, (int, float)):
                    return left - right
            elif op == '*':
                if isinstance(left, (int, float)) and isinstance(right, (int, float)):
                    return left * right
            elif op == '/':
                if isinstance(left, (int, float)) and isinstance(right, (int, float)) and right != 0:
                    return left / right if isinstance(left, float) or isinstance(right, float) else left // right
            elif op == '==':
                return left == right
            elif op == '!=':
                return left != right
            elif op == '>':
                return left > right
            elif op == '>=':
                return left >= right
            elif op == '<':
                return left < right
            elif op == '<=':
                return left <= right
        except Exception:
            return None
        return None
