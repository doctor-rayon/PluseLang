from typing import List, Set
from pulse.parser.ast import (
    ASTNode, ProgramNode, StatementNode, ExpressionNode,
    VarDeclNode, StateDeclNode, AssignmentNode, WatchNode, WhenClauseNode,
    BinaryOpNode, UnaryOpNode, LiteralNode, IdentifierNode, PrintStmtNode,
    BlockStmtNode, IfStmtNode, WhileStmtNode
)
from .instructions import IROp, IRInstruction, IRProgram, IRWatcherBlock


class IRBuilder:
    def __init__(self):
        self.instructions: List[IRInstruction] = []
        self.state_vars: Set[str] = set()
        self.watchers: List[IRWatcherBlock] = []
        self.label_counter = 0
        self.watcher_counter = 0

    def build(self, ast: ProgramNode) -> IRProgram:
        self.instructions = []
        self.state_vars = set()
        self.watchers = []
        self.label_counter = 0
        self.watcher_counter = 0

        # First pass to collect state variable declarations so identifier lookups know if var is state
        self._collect_state_vars(ast)

        for stmt in ast.statements:
            self._visit_stmt(stmt)

        self.instructions.append(IRInstruction(op=IROp.HALT))
        return IRProgram(
            instructions=self.instructions,
            state_variables=list(self.state_vars),
            watchers=self.watchers
        )

    def _new_label(self, prefix: str = "L") -> str:
        self.label_counter += 1
        return f"{prefix}_{self.label_counter}"

    def _new_watcher_id(self) -> str:
        self.watcher_counter += 1
        return f"watcher_{self.watcher_counter}"

    def _collect_state_vars(self, node: ASTNode) -> None:
        if isinstance(node, StateDeclNode):
            self.state_vars.add(node.name)
        elif isinstance(node, ProgramNode) or isinstance(node, BlockStmtNode):
            for stmt in node.statements:
                self._collect_state_vars(stmt)

    # --- Statement Visitor ---

    def _visit_stmt(self, node: StatementNode) -> None:
        if isinstance(node, VarDeclNode):
            if node.initializer:
                self._visit_expr(node.initializer)
            else:
                self.instructions.append(IRInstruction(op=IROp.CONST, arg=None, line=node.line, column=node.column))
            self.instructions.append(IRInstruction(op=IROp.STORE_VAR, arg=node.name, line=node.line, column=node.column))

        elif isinstance(node, StateDeclNode):
            if node.initializer:
                self._visit_expr(node.initializer)
            else:
                self.instructions.append(IRInstruction(op=IROp.CONST, arg=None, line=node.line, column=node.column))
            self.instructions.append(IRInstruction(op=IROp.STATE_CREATE, arg=node.name, line=node.line, column=node.column))

        elif isinstance(node, AssignmentNode):
            self._visit_expr(node.value)
            if node.name in self.state_vars:
                self.instructions.append(IRInstruction(op=IROp.STATE_SET, arg=node.name, line=node.line, column=node.column))
            else:
                self.instructions.append(IRInstruction(op=IROp.STORE_VAR, arg=node.name, line=node.line, column=node.column))

        elif isinstance(node, PrintStmtNode):
            self._visit_expr(node.expression)
            self.instructions.append(IRInstruction(op=IROp.PRINT, line=node.line, column=node.column))

        elif isinstance(node, BlockStmtNode):
            for s in node.statements:
                self._visit_stmt(s)

        elif isinstance(node, IfStmtNode):
            else_label = self._new_label("else")
            end_label = self._new_label("endif")

            self._visit_expr(node.condition)
            self.instructions.append(IRInstruction(op=IROp.JUMP_IF_FALSE, arg=else_label, line=node.line, column=node.column))

            self._visit_stmt(node.then_branch)
            self.instructions.append(IRInstruction(op=IROp.JUMP, arg=end_label, line=node.line, column=node.column))

            self.instructions.append(IRInstruction(op=IROp.LABEL, arg=else_label, line=node.line, column=node.column))
            if node.else_branch:
                self._visit_stmt(node.else_branch)

            self.instructions.append(IRInstruction(op=IROp.LABEL, arg=end_label, line=node.line, column=node.column))

        elif isinstance(node, WhileStmtNode):
            start_label = self._new_label("while_start")
            end_label = self._new_label("while_end")

            self.instructions.append(IRInstruction(op=IROp.LABEL, arg=start_label, line=node.line, column=node.column))
            self._visit_expr(node.condition)
            self.instructions.append(IRInstruction(op=IROp.JUMP_IF_FALSE, arg=end_label, line=node.line, column=node.column))

            self._visit_stmt(node.body)
            self.instructions.append(IRInstruction(op=IROp.JUMP, arg=start_label, line=node.line, column=node.column))

            self.instructions.append(IRInstruction(op=IROp.LABEL, arg=end_label, line=node.line, column=node.column))

        elif isinstance(node, WatchNode):
            for clause in node.when_clauses:
                watcher_id = self._new_watcher_id()

                # Build condition instructions for this watcher clause
                cond_builder = IRBuilder()
                cond_builder.state_vars = self.state_vars
                cond_builder._visit_expr(clause.condition)

                # Build body instructions for this watcher clause
                body_builder = IRBuilder()
                body_builder.state_vars = self.state_vars
                body_builder._visit_stmt(clause.body)

                watcher_block = IRWatcherBlock(
                    id=watcher_id,
                    target_name=node.target_name,
                    condition_instructions=cond_builder.instructions,
                    body_instructions=body_builder.instructions
                )
                self.watchers.append(watcher_block)
                self.instructions.append(IRInstruction(op=IROp.WATCH_CREATE, arg=(node.target_name, watcher_id), line=node.line, column=node.column))

        elif isinstance(node, ExpressionNode):
            self._visit_expr(node)

    # --- Expression Visitor ---

    def _visit_expr(self, node: ExpressionNode) -> None:
        if isinstance(node, LiteralNode):
            self.instructions.append(IRInstruction(op=IROp.CONST, arg=node.value, line=node.line, column=node.column))

        elif isinstance(node, IdentifierNode):
            if node.name in self.state_vars:
                self.instructions.append(IRInstruction(op=IROp.STATE_GET, arg=node.name, line=node.line, column=node.column))
            else:
                self.instructions.append(IRInstruction(op=IROp.LOAD_VAR, arg=node.name, line=node.line, column=node.column))

        elif isinstance(node, BinaryOpNode):
            self._visit_expr(node.left)
            self._visit_expr(node.right)
            self.instructions.append(IRInstruction(op=IROp.BINARY_OP, arg=node.operator, line=node.line, column=node.column))

        elif isinstance(node, UnaryOpNode):
            self._visit_expr(node.operand)
            self.instructions.append(IRInstruction(op=IROp.UNARY_OP, arg=node.operator, line=node.line, column=node.column))
