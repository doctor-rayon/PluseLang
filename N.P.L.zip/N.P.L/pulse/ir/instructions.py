from enum import Enum, auto
from dataclasses import dataclass, field
from typing import List, Any, Optional, Dict


class IROp(Enum):
    CONST = auto()          # Push constant onto evaluation stack
    LOAD_VAR = auto()       # Load local/global let variable
    STORE_VAR = auto()      # Store into local/global let variable
    STATE_CREATE = auto()   # Declare a state variable
    STATE_GET = auto()      # Read value of a state variable
    STATE_SET = auto()      # Set value of a state variable & trigger reactive watchers
    WATCH_CREATE = auto()   # Register a watcher for target state variable
    BINARY_OP = auto()      # +, -, *, /, %, ==, !=, >, >=, <, <=, &&, ||
    UNARY_OP = auto()       # !, -
    JUMP = auto()           # Unconditional jump to label
    JUMP_IF_FALSE = auto() # Jump to label if popped stack top is false/falsy
    LABEL = auto()          # Target label marker
    PRINT = auto()          # Print top of stack
    HALT = auto()           # End execution


@dataclass
class IRInstruction:
    op: IROp
    arg: Any = None
    line: int = 1
    column: int = 1

    def __repr__(self) -> str:
        if self.arg is not None:
            return f"{self.op.name} {self.arg}"
        return f"{self.op.name}"


@dataclass
class IRWatcherBlock:
    id: str
    target_name: str
    condition_instructions: List[IRInstruction]
    body_instructions: List[IRInstruction]


@dataclass
class IRProgram:
    instructions: List[IRInstruction] = field(default_factory=list)
    state_variables: List[str] = field(default_factory=list)
    watchers: List[IRWatcherBlock] = field(default_factory=list)

    def dump(self) -> str:
        lines = ["=== Pulse IR Program ==="]
        if self.state_variables:
            lines.append(f"States: {', '.join(self.state_variables)}")
        if self.watchers:
            lines.append("Watchers:")
            for w in self.watchers:
                lines.append(f"  Watcher '{w.id}' watching '{w.target_name}':")
                lines.append("    Condition:")
                for instr in w.condition_instructions:
                    lines.append(f"      {instr}")
                lines.append("    Body:")
                for instr in w.body_instructions:
                    lines.append(f"      {instr}")
        lines.append("Main Code:")
        for idx, instr in enumerate(self.instructions):
            lines.append(f"  {idx:04d}: {instr}")
        return "\n".join(lines)
