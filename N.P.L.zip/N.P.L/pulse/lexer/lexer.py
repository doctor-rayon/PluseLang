from typing import List, Any
from .token import Token, TokenType, KEYWORDS


class LexerError(Exception):
    def __init__(self, message: str, line: int, column: int):
        super().__init__(f"LexerError at Line {line}, Column {column}: {message}")
        self.message = message
        self.line = line
        self.column = column


class Lexer:
    def __init__(self, source: str, file_path: str = "<stdin>"):
        self.source = source
        self.file_path = file_path
        self.tokens: List[Token] = []
        self.start = 0
        self.current = 0
        self.line = 1
        self.column = 1
        self.token_start_column = 1

    def tokenize(self) -> List[Token]:
        while not self._is_at_end():
            self.start = self.current
            self.token_start_column = self.column
            self._scan_token()

        self.tokens.append(Token(TokenType.EOF, "", None, self.line, self.column))
        return self.tokens

    def _is_at_end(self) -> bool:
        return self.current >= len(self.source)

    def _advance(self) -> str:
        c = self.source[self.current]
        self.current += 1
        self.column += 1
        return c

    def _peek(self) -> str:
        if self._is_at_end():
            return '\0'
        return self.source[self.current]

    def _peek_next(self) -> str:
        if self.current + 1 >= len(self.source):
            return '\0'
        return self.source[self.current + 1]

    def _match(self, expected: str) -> bool:
        if self._is_at_end():
            return False
        if self.source[self.current] != expected:
            return False
        self.current += 1
        self.column += 1
        return True

    def _scan_token(self) -> None:
        c = self._advance()

        # Whitespace
        if c in ' \r\t':
            return
        if c == '\n':
            self.line += 1
            self.column = 1
            return

        # Single char / multi char operators & punctuation
        if c == '+':
            self._add_token(TokenType.PLUS)
        elif c == '-':
            self._add_token(TokenType.MINUS)
        elif c == '*':
            self._add_token(TokenType.STAR)
        elif c == '/':
            if self._match('/'):
                # Single-line comment
                while self._peek() != '\n' and not self._is_at_end():
                    self._advance()
            elif self._match('*'):
                # Block comment
                while not self._is_at_end():
                    if self._peek() == '*' and self._peek_next() == '/':
                        self._advance()  # *
                        self._advance()  # /
                        break
                    if self._peek() == '\n':
                        self.line += 1
                        self.column = 1
                        self._advance()
                    else:
                        self._advance()
            else:
                self._add_token(TokenType.SLASH)
        elif c == '%':
            self._add_token(TokenType.MODULO)
        elif c == '=':
            if self._match('='):
                self._add_token(TokenType.EQ)
            elif self._match('>'):
                self._add_token(TokenType.FAT_ARROW)
            else:
                self._add_token(TokenType.EQUAL)
        elif c == '!':
            if self._match('='):
                self._add_token(TokenType.NEQ)
            else:
                self._add_token(TokenType.NOT)
        elif c == '<':
            if self._match('='):
                self._add_token(TokenType.LTE)
            else:
                self._add_token(TokenType.LT)
        elif c == '>':
            if self._match('='):
                self._add_token(TokenType.GTE)
            else:
                self._add_token(TokenType.GT)
        elif c == '&':
            if self._match('&'):
                self._add_token(TokenType.AND)
            else:
                raise LexerError(f"Unexpected character '{c}', expected '&&'", self.line, self.token_start_column)
        elif c == '|':
            if self._match('|'):
                self._add_token(TokenType.OR)
            else:
                raise LexerError(f"Unexpected character '{c}', expected '||'", self.line, self.token_start_column)
        elif c == '{':
            self._add_token(TokenType.LBRACE)
        elif c == '}':
            self._add_token(TokenType.RBRACE)
        elif c == '(':
            self._add_token(TokenType.LPAREN)
        elif c == ')':
            self._add_token(TokenType.RPAREN)
        elif c == '[':
            self._add_token(TokenType.LBRACKET)
        elif c == ']':
            self._add_token(TokenType.RBRACKET)
        elif c == ':':
            self._add_token(TokenType.COLON)
        elif c == ';':
            self._add_token(TokenType.SEMICOLON)
        elif c == ',':
            self._add_token(TokenType.COMMA)
        elif c == '.':
            self._add_token(TokenType.DOT)
        elif c == '"':
            self._string()
        elif c.isdigit():
            self._number()
        elif c.isalpha() or c == '_':
            self._identifier()
        else:
            raise LexerError(f"Unexpected character '{c}'", self.line, self.token_start_column)

    def _string(self) -> None:
        val = []
        start_line = self.line
        start_col = self.token_start_column

        while self._peek() != '"' and not self._is_at_end():
            if self._peek() == '\n':
                self.line += 1
                self.column = 1
                val.append(self._advance())
            elif self._peek() == '\\':
                self._advance()
                escaped = self._advance()
                if escaped == 'n':
                    val.append('\n')
                elif escaped == 't':
                    val.append('\t')
                elif escaped == 'r':
                    val.append('\r')
                elif escaped == '"':
                    val.append('"')
                elif escaped == '\\':
                    val.append('\\')
                else:
                    val.append(escaped)
            else:
                val.append(self._advance())

        if self._is_at_end():
            raise LexerError("Unterminated string literal", start_line, start_col)

        # Consume closing quote
        self._advance()
        string_val = "".join(val)
        lexeme = self.source[self.start:self.current]
        self.tokens.append(Token(TokenType.STRING, lexeme, string_val, start_line, start_col))

    def _number(self) -> None:
        is_float = False
        while self._peek().isdigit():
            self._advance()

        if self._peek() == '.' and self._peek_next().isdigit():
            is_float = True
            self._advance()  # Consume '.'
            while self._peek().isdigit():
                self._advance()

        lexeme = self.source[self.start:self.current]
        val = float(lexeme) if is_float else int(lexeme)
        self.tokens.append(Token(TokenType.NUMBER, lexeme, val, self.line, self.token_start_column))

    def _identifier(self) -> None:
        while self._peek().isalnum() or self._peek() == '_':
            self._advance()

        lexeme = self.source[self.start:self.current]
        token_type = KEYWORDS.get(lexeme, TokenType.IDENTIFIER)
        val = None
        if token_type == TokenType.TRUE:
            val = True
        elif token_type == TokenType.FALSE:
            val = False
        elif token_type == TokenType.NULL:
            val = None

        self.tokens.append(Token(token_type, lexeme, val, self.line, self.token_start_column))

    def _add_token(self, token_type: TokenType, value: Any = None) -> None:
        lexeme = self.source[self.start:self.current]
        self.tokens.append(Token(token_type, lexeme, value, self.line, self.token_start_column))
