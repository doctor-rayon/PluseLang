from enum import Enum, auto
from dataclasses import dataclass
from typing import Any


class TokenType(Enum):
    # Keywords
    LET = auto()
    STATE = auto()
    WATCH = auto()
    WHEN = auto()
    IF = auto()
    ELSE = auto()
    WHILE = auto()
    FOR = auto()
    IN = auto()
    FN = auto()
    RETURN = auto()
    PRINT = auto()
    TRUE = auto()
    FALSE = auto()
    NULL = auto()

    # Identifiers & Literals
    IDENTIFIER = auto()
    NUMBER = auto()
    STRING = auto()

    # Operators
    PLUS = auto()         # +
    MINUS = auto()        # -
    STAR = auto()         # *
    SLASH = auto()        # /
    MODULO = auto()       # %
    EQUAL = auto()        # =
    EQ = auto()           # ==
    NEQ = auto()          # !=
    GT = auto()           # >
    GTE = auto()          # >=
    LT = auto()           # <
    LTE = auto()          # <=
    AND = auto()          # &&
    OR = auto()           # ||
    NOT = auto()          # !
    FAT_ARROW = auto()    # =>

    # Delimiters
    LBRACE = auto()       # {
    RBRACE = auto()       # }
    LPAREN = auto()       # (
    RPAREN = auto()       # )
    LBRACKET = auto()     # [
    RBRACKET = auto()     # ]
    COLON = auto()        # :
    SEMICOLON = auto()    # ;
    COMMA = auto()        # ,
    DOT = auto()          # .

    # Special
    EOF = auto()


KEYWORDS = {
    "let": TokenType.LET,
    "state": TokenType.STATE,
    "watch": TokenType.WATCH,
    "when": TokenType.WHEN,
    "if": TokenType.IF,
    "else": TokenType.ELSE,
    "while": TokenType.WHILE,
    "for": TokenType.FOR,
    "in": TokenType.IN,
    "fn": TokenType.FN,
    "return": TokenType.RETURN,
    "print": TokenType.PRINT,
    "true": TokenType.TRUE,
    "false": TokenType.FALSE,
    "null": TokenType.NULL,
}


@dataclass
class Token:
    type: TokenType
    lexeme: str
    value: Any
    line: int
    column: int

    def __repr__(self) -> str:
        return f"Token({self.type.name}, '{self.lexeme}', val={self.value}, L{self.line}:C{self.column})"
