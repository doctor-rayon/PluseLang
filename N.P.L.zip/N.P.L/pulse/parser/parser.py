from typing import List, Optional
from pulse.lexer.token import Token, TokenType
from .ast import (
    ASTNode, ProgramNode, StatementNode, ExpressionNode,
    VarDeclNode, StateDeclNode, AssignmentNode, WatchNode, WhenClauseNode,
    BinaryOpNode, UnaryOpNode, LiteralNode, IdentifierNode, PrintStmtNode,
    BlockStmtNode, IfStmtNode, WhileStmtNode
)


class ParseError(Exception):
    def __init__(self, message: str, token: Token):
        super().__init__(f"ParseError at Line {token.line}, Column {token.column} (near '{token.lexeme}'): {message}")
        self.message = message
        self.token = token


class Parser:
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.current = 0

    def parse(self) -> ProgramNode:
        statements: List[StatementNode] = []
        while not self._is_at_end():
            stmt = self._declaration()
            if stmt:
                statements.append(stmt)
        first_token = self.tokens[0] if self.tokens else Token(TokenType.EOF, "", None, 1, 1)
        return ProgramNode(statements=statements, line=first_token.line, column=first_token.column)

    # --- Helper methods ---

    def _is_at_end(self) -> bool:
        return self._peek().type == TokenType.EOF

    def _peek(self) -> Token:
        return self.tokens[self.current]

    def _previous(self) -> Token:
        return self.tokens[self.current - 1]

    def _advance(self) -> Token:
        if not self._is_at_end():
            self.current += 1
        return self._previous()

    def _check(self, token_type: TokenType) -> bool:
        if self._is_at_end():
            return False
        return self._peek().type == token_type

    def _match(self, *token_types: TokenType) -> bool:
        for t in token_types:
            if self._check(t):
                self._advance()
                return True
        return False

    def _consume(self, token_type: TokenType, message: str) -> Token:
        if self._check(token_type):
            return self._advance()
        raise ParseError(message, self._peek())

    # --- Declarations & Statements ---

    def _declaration(self) -> StatementNode:
        if self._match(TokenType.LET):
            return self._var_declaration()
        if self._match(TokenType.STATE):
            return self._state_declaration()
        if self._match(TokenType.WATCH):
            return self._watch_statement()
        return self._statement()

    def _var_declaration(self) -> VarDeclNode:
        let_token = self._previous()
        name_token = self._consume(TokenType.IDENTIFIER, "Expected variable name after 'let'.")
        type_annotation = None

        if self._match(TokenType.COLON):
            type_token = self._consume(TokenType.IDENTIFIER, "Expected type name after ':'.")
            type_annotation = type_token.lexeme

        initializer = None
        if self._match(TokenType.EQUAL):
            initializer = self._expression()

        self._match(TokenType.SEMICOLON)  # Optional semicolon
        return VarDeclNode(
            name=name_token.lexeme,
            type_annotation=type_annotation,
            initializer=initializer,
            line=let_token.line,
            column=let_token.column
        )

    def _state_declaration(self) -> StateDeclNode:
        state_token = self._previous()
        name_token = self._consume(TokenType.IDENTIFIER, "Expected state variable name after 'state'.")
        type_annotation = None

        if self._match(TokenType.COLON):
            type_token = self._consume(TokenType.IDENTIFIER, "Expected type name after ':'.")
            type_annotation = type_token.lexeme

        initializer = None
        if self._match(TokenType.EQUAL):
            initializer = self._expression()

        self._match(TokenType.SEMICOLON)
        return StateDeclNode(
            name=name_token.lexeme,
            type_annotation=type_annotation,
            initializer=initializer,
            line=state_token.line,
            column=state_token.column
        )

    def _watch_statement(self) -> WatchNode:
        watch_token = self._previous()
        target_token = self._consume(TokenType.IDENTIFIER, "Expected observable state variable name after 'watch'.")
        self._consume(TokenType.LBRACE, "Expected '{' to start watch block.")

        when_clauses: List[WhenClauseNode] = []
        while not self._check(TokenType.RBRACE) and not self._is_at_end():
            self._consume(TokenType.WHEN, "Expected 'when' clause inside watch block.")
            when_token = self._previous()
            condition = self._expression()

            body: StatementNode
            if self._match(TokenType.FAT_ARROW):
                body = self._statement()
            elif self._check(TokenType.LBRACE):
                body = self._block_statement()
            else:
                raise ParseError("Expected '=>' or '{' after when clause condition.", self._peek())

            when_clauses.append(WhenClauseNode(condition=condition, body=body, line=when_token.line, column=when_token.column))

        self._consume(TokenType.RBRACE, "Expected '}' to close watch block.")
        return WatchNode(target_name=target_token.lexeme, when_clauses=when_clauses, line=watch_token.line, column=watch_token.column)

    def _statement(self) -> StatementNode:
        if self._match(TokenType.IF):
            return self._if_statement()
        if self._match(TokenType.WHILE):
            return self._while_statement()
        if self._match(TokenType.PRINT):
            return self._print_statement()
        if self._check(TokenType.LBRACE):
            return self._block_statement()

        return self._expression_statement()

    def _if_statement(self) -> IfStmtNode:
        if_token = self._previous()
        condition = self._expression()
        then_branch = self._statement()
        else_branch = None
        if self._match(TokenType.ELSE):
            else_branch = self._statement()
        return IfStmtNode(condition=condition, then_branch=then_branch, else_branch=else_branch, line=if_token.line, column=if_token.column)

    def _while_statement(self) -> WhileStmtNode:
        while_token = self._previous()
        condition = self._expression()
        body = self._statement()
        return WhileStmtNode(condition=condition, body=body, line=while_token.line, column=while_token.column)

    def _print_statement(self) -> PrintStmtNode:
        print_token = self._previous()
        has_paren = self._match(TokenType.LPAREN)
        expr = self._expression()
        if has_paren:
            self._consume(TokenType.RPAREN, "Expected ')' after print expression.")
        self._match(TokenType.SEMICOLON)
        return PrintStmtNode(expression=expr, line=print_token.line, column=print_token.column)

    def _block_statement(self) -> BlockStmtNode:
        lbrace = self._consume(TokenType.LBRACE, "Expected '{' to start block.")
        statements: List[StatementNode] = []
        while not self._check(TokenType.RBRACE) and not self._is_at_end():
            stmt = self._declaration()
            if stmt:
                statements.append(stmt)
        self._consume(TokenType.RBRACE, "Expected '}' after block.")
        return BlockStmtNode(statements=statements, line=lbrace.line, column=lbrace.column)

    def _expression_statement(self) -> StatementNode:
        expr = self._expression()
        # Assignment check if target is identifier followed by '='
        if isinstance(expr, IdentifierNode) and self._match(TokenType.EQUAL):
            val_expr = self._expression()
            self._match(TokenType.SEMICOLON)
            return AssignmentNode(name=expr.name, value=val_expr, line=expr.line, column=expr.column)

        self._match(TokenType.SEMICOLON)
        return expr  # Expression as statement

    # --- Expression Parsing with Precedence ---

    def _expression(self) -> ExpressionNode:
        return self._assignment_expr()

    def _assignment_expr(self) -> ExpressionNode:
        expr = self._logical_or()
        if isinstance(expr, IdentifierNode) and self._match(TokenType.EQUAL):
            val = self._assignment_expr()
            return AssignmentNode(name=expr.name, value=val, line=expr.line, column=expr.column)
        return expr

    def _logical_or(self) -> ExpressionNode:
        expr = self._logical_and()
        while self._match(TokenType.OR):
            op_token = self._previous()
            right = self._logical_and()
            expr = BinaryOpNode(left=expr, operator=op_token.lexeme, right=right, line=op_token.line, column=op_token.column)
        return expr

    def _logical_and(self) -> ExpressionNode:
        expr = self._equality()
        while self._match(TokenType.AND):
            op_token = self._previous()
            right = self._equality()
            expr = BinaryOpNode(left=expr, operator=op_token.lexeme, right=right, line=op_token.line, column=op_token.column)
        return expr

    def _equality(self) -> ExpressionNode:
        expr = self._comparison()
        while self._match(TokenType.EQ, TokenType.NEQ):
            op_token = self._previous()
            right = self._comparison()
            expr = BinaryOpNode(left=expr, operator=op_token.lexeme, right=right, line=op_token.line, column=op_token.column)
        return expr

    def _comparison(self) -> ExpressionNode:
        expr = self._term()
        while self._match(TokenType.GT, TokenType.GTE, TokenType.LT, TokenType.LTE):
            op_token = self._previous()
            right = self._term()
            expr = BinaryOpNode(left=expr, operator=op_token.lexeme, right=right, line=op_token.line, column=op_token.column)
        return expr

    def _term(self) -> ExpressionNode:
        expr = self._factor()
        while self._match(TokenType.PLUS, TokenType.MINUS):
            op_token = self._previous()
            right = self._factor()
            expr = BinaryOpNode(left=expr, operator=op_token.lexeme, right=right, line=op_token.line, column=op_token.column)
        return expr

    def _factor(self) -> ExpressionNode:
        expr = self._unary()
        while self._match(TokenType.STAR, TokenType.SLASH, TokenType.MODULO):
            op_token = self._previous()
            right = self._unary()
            expr = BinaryOpNode(left=expr, operator=op_token.lexeme, right=right, line=op_token.line, column=op_token.column)
        return expr

    def _unary(self) -> ExpressionNode:
        if self._match(TokenType.NOT, TokenType.MINUS):
            op_token = self._previous()
            operand = self._unary()
            return UnaryOpNode(operator=op_token.lexeme, operand=operand, line=op_token.line, column=op_token.column)
        return self._primary()

    def _primary(self) -> ExpressionNode:
        if self._match(TokenType.NUMBER, TokenType.STRING, TokenType.TRUE, TokenType.FALSE, TokenType.NULL):
            token = self._previous()
            return LiteralNode(value=token.value, line=token.line, column=token.column)

        if self._match(TokenType.IDENTIFIER):
            token = self._previous()
            return IdentifierNode(name=token.lexeme, line=token.line, column=token.column)

        if self._match(TokenType.LPAREN):
            expr = self._expression()
            self._consume(TokenType.RPAREN, "Expected ')' after expression.")
            return expr

        raise ParseError(f"Unexpected token '{self._peek().lexeme}'", self._peek())
