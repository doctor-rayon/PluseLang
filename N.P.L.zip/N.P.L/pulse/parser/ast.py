from dataclasses import dataclass, field
from typing import List, Optional, Any


@dataclass
class ASTNode:
    line: int = 1
    column: int = 1


@dataclass
class ExpressionNode(ASTNode):
    pass


@dataclass
class StatementNode(ASTNode):
    pass


@dataclass
class ProgramNode(ASTNode):
    statements: List[StatementNode] = field(default_factory=list)


@dataclass
class LiteralNode(ExpressionNode):
    value: Any = None


@dataclass
class IdentifierNode(ExpressionNode):
    name: str = ""


@dataclass
class BinaryOpNode(ExpressionNode):
    left: ExpressionNode = field(default_factory=ExpressionNode)
    operator: str = ""
    right: ExpressionNode = field(default_factory=ExpressionNode)


@dataclass
class UnaryOpNode(ExpressionNode):
    operator: str = ""
    operand: ExpressionNode = field(default_factory=ExpressionNode)


@dataclass
class VarDeclNode(StatementNode):
    name: str = ""
    type_annotation: Optional[str] = None
    initializer: Optional[ExpressionNode] = None


@dataclass
class StateDeclNode(StatementNode):
    name: str = ""
    type_annotation: Optional[str] = None
    initializer: Optional[ExpressionNode] = None


@dataclass
class AssignmentNode(StatementNode):
    name: str = ""
    value: ExpressionNode = field(default_factory=ExpressionNode)


@dataclass
class PrintStmtNode(StatementNode):
    expression: ExpressionNode = field(default_factory=ExpressionNode)


@dataclass
class BlockStmtNode(StatementNode):
    statements: List[StatementNode] = field(default_factory=list)


@dataclass
class WhenClauseNode(ASTNode):
    condition: ExpressionNode = field(default_factory=ExpressionNode)
    body: StatementNode = field(default_factory=StatementNode)


@dataclass
class WatchNode(StatementNode):
    target_name: str = ""
    when_clauses: List[WhenClauseNode] = field(default_factory=list)


@dataclass
class IfStmtNode(StatementNode):
    condition: ExpressionNode = field(default_factory=ExpressionNode)
    then_branch: StatementNode = field(default_factory=StatementNode)
    else_branch: Optional[StatementNode] = None


@dataclass
class WhileStmtNode(StatementNode):
    condition: ExpressionNode = field(default_factory=ExpressionNode)
    body: StatementNode = field(default_factory=StatementNode)
