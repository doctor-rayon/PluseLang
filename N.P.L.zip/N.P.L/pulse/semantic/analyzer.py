from pulse.parser.ast import (
    ASTNode, ProgramNode, StatementNode, ExpressionNode,
    VarDeclNode, StateDeclNode, AssignmentNode, WatchNode, WhenClauseNode,
    BinaryOpNode, UnaryOpNode, LiteralNode, IdentifierNode, PrintStmtNode,
    BlockStmtNode, IfStmtNode, WhileStmtNode
)
from .symbol_table import SymbolTable, Symbol


class SemanticError(Exception):
    def __init__(self, message: str, line: int, column: int, file_path: str = "<stdin>"):
        super().__init__(f"SemanticError in '{file_path}' at Line {line}, Column {column}:\n  {message}")
        self.message = message
        self.line = line
        self.column = column
        self.file_path = file_path


class SemanticAnalyzer:
    def __init__(self, file_path: str = "<stdin>"):
        self.file_path = file_path
        self.symbol_table = SymbolTable()

    def analyze(self, node: ASTNode) -> None:
        self._visit(node)

    def _visit(self, node: ASTNode) -> None:
        method_name = f"_visit_{node.__class__.__name__}"
        visitor = getattr(self, method_name, self._generic_visit)
        visitor(node)

    def _generic_visit(self, node: ASTNode) -> None:
        for attr in dir(node):
            if attr.startswith('_'):
                continue
            val = getattr(node, attr)
            if isinstance(val, ASTNode):
                self._visit(val)
            elif isinstance(val, list):
                for item in val:
                    if isinstance(item, ASTNode):
                        self._visit(item)

    def _visit_ProgramNode(self, node: ProgramNode) -> None:
        for stmt in node.statements:
            self._visit(stmt)

    def _visit_VarDeclNode(self, node: VarDeclNode) -> None:
        if node.initializer:
            self._visit(node.initializer)

        symbol = Symbol(
            name=node.name,
            is_state=False,
            type_annotation=node.type_annotation,
            line=node.line,
            column=node.column
        )
        if not self.symbol_table.define(symbol):
            raise SemanticError(
                f"Variable '{node.name}' is already declared in this scope.",
                node.line, node.column, self.file_path
            )

    def _visit_StateDeclNode(self, node: StateDeclNode) -> None:
        if node.initializer:
            self._visit(node.initializer)

        symbol = Symbol(
            name=node.name,
            is_state=True,
            type_annotation=node.type_annotation,
            line=node.line,
            column=node.column
        )
        if not self.symbol_table.define(symbol):
            raise SemanticError(
                f"State variable '{node.name}' is already declared in this scope.",
                node.line, node.column, self.file_path
            )

    def _visit_AssignmentNode(self, node: AssignmentNode) -> None:
        symbol = self.symbol_table.lookup(node.name)
        if not symbol:
            raise SemanticError(
                f"Cannot assign to undefined variable '{node.name}'.",
                node.line, node.column, self.file_path
            )
        self._visit(node.value)

    def _visit_WatchNode(self, node: WatchNode) -> None:
        symbol = self.symbol_table.lookup(node.target_name)
        if not symbol:
            raise SemanticError(
                f"Watch target '{node.target_name}' is not defined.",
                node.line, node.column, self.file_path
            )
        if not symbol.is_state:
            raise SemanticError(
                f"Cannot watch variable '{node.target_name}' because it was declared with 'let'. Only 'state' variables can be watched.",
                node.line, node.column, self.file_path
            )

        for clause in node.when_clauses:
            self._visit(clause)

    def _visit_WhenClauseNode(self, node: WhenClauseNode) -> None:
        self._visit(node.condition)
        self._visit(node.body)

    def _visit_IdentifierNode(self, node: IdentifierNode) -> None:
        symbol = self.symbol_table.lookup(node.name)
        if not symbol:
            raise SemanticError(
                f"Variable '{node.name}' is not defined.",
                node.line, node.column, self.file_path
            )

    def _visit_BlockStmtNode(self, node: BlockStmtNode) -> None:
        self.symbol_table.enter_scope()
        for stmt in node.statements:
            self._visit(stmt)
        self.symbol_table.exit_scope()

    def _visit_IfStmtNode(self, node: IfStmtNode) -> None:
        self._visit(node.condition)
        self._visit(node.then_branch)
        if node.else_branch:
            self._visit(node.else_branch)

    def _visit_WhileStmtNode(self, node: WhileStmtNode) -> None:
        self._visit(node.condition)
        self._visit(node.body)

    def _visit_PrintStmtNode(self, node: PrintStmtNode) -> None:
        self._visit(node.expression)

    def _visit_BinaryOpNode(self, node: BinaryOpNode) -> None:
        self._visit(node.left)
        self._visit(node.right)

    def _visit_UnaryOpNode(self, node: UnaryOpNode) -> None:
        self._visit(node.operand)

    def _visit_LiteralNode(self, node: LiteralNode) -> None:
        pass
