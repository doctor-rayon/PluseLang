import os
import sys
import subprocess
import shutil
from typing import Optional
from pulse.compiler.serializer import CompiledBytecode, BytecodeSerializer


def build_windows_executable(compiled: CompiledBytecode, output_name: str, dist_dir: str = "dist", build_dir: str = "build") -> str:
    os.makedirs(build_dir, exist_ok=True)
    os.makedirs(dist_dir, exist_ok=True)

    serializer = BytecodeSerializer()
    bytecode_bytes = serializer.serialize(compiled)

    launcher_path = os.path.join(build_dir, f"{output_name}_launcher.py")

    # Generate self-contained standalone launcher script embedding bytecode bytes
    launcher_code = f"""import sys
import io
import os
from pulse.vm.loader import BytecodeLoader
from pulse.vm.vm import PulseVM

BYTECODE_DATA = {repr(bytecode_bytes)}

def main():
    try:
        loader = BytecodeLoader()
        compiled = loader.load_from_bytes(BYTECODE_DATA)
        vm = PulseVM()
        vm.run(compiled, file_path="{output_name}.pulse")
    except Exception as e:
        print(f"Runtime Error: {{e}}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
"""
    with open(launcher_path, "w", encoding="utf-8") as f:
        f.write(launcher_code)

    # Check if pyinstaller is available
    pyinstaller_bin = shutil.which("pyinstaller")
    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--onefile",
        "--name", output_name,
        "--distpath", dist_dir,
        "--workpath", os.path.join(build_dir, "pyi_work"),
        "--specpath", os.path.join(build_dir, "pyi_spec"),
        launcher_path
    ]

    try:
        subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except subprocess.CalledProcessError as e:
        err_msg = e.stderr.decode("utf-8", errors="ignore") if e.stderr else str(e)
        raise RuntimeError(f"Failed to build Windows executable: {err_msg}")

    exe_path = os.path.join(dist_dir, f"{output_name}.exe")
    return exe_path
