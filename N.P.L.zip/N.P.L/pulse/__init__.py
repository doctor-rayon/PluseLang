"""
Pulse Programming Language Package
"""

__version__ = "0.1.0"
