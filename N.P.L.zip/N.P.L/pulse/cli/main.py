import sys
import os
import argparse
from typing import Optional
from pulse.lexer.lexer import Lexer, LexerError
from pulse.parser.parser import Parser, ParseError
from pulse.semantic.analyzer import SemanticAnalyzer, SemanticError
from pulse.ir.builder import IRBuilder
from pulse.compiler.optimizer import Optimizer
from pulse.compiler.serializer import BytecodeSerializer, MAGIC
from pulse.vm.loader import BytecodeLoader
from pulse.vm.vm import PulseVM, PulseVMError
from pulse.runtime.interpreter import Interpreter
from pulse.runtime.environment import RuntimeError as PulseRuntimeError
from pulse.runtime.reactive_engine import ReactiveCycleError
from pulse.native.win_builder import build_windows_executable
from pulse import __version__


def run_file(file_path: str) -> int:
    if not os.path.exists(file_path):
        print(f"Error: File '{file_path}' not found.", file=sys.stderr)
        return 1

    try:
        with open(file_path, "rb") as f:
            header = f.read(6)

        # Auto-detect binary .pulsec bytecode file vs .pulse text source
        if header == MAGIC:
            loader = BytecodeLoader()
            compiled = loader.load_from_file(file_path)
            vm = PulseVM()
            vm.run(compiled, file_path=file_path)
            return 0

        # Text source file
        with open(file_path, "r", encoding="utf-8") as f:
            source = f.read()

        lexer = Lexer(source, file_path=file_path)
        tokens = lexer.tokenize()

        parser = Parser(tokens)
        ast = parser.parse()

        analyzer = SemanticAnalyzer(file_path=file_path)
        analyzer.analyze(ast)

        # Run via Pulse Stack-Based Bytecode VM
        ir_program = IRBuilder().build(ast)
        opt_ir = Optimizer().optimize(ir_program)
        compiled = BytecodeSerializer().compile_ir(opt_ir)

        vm = PulseVM()
        vm.run(compiled, file_path=file_path)
        return 0

    except (LexerError, ParseError, SemanticError, PulseRuntimeError, PulseVMError, ReactiveCycleError) as e:
        print(f"\n{e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"\nUnexpected Compiler Error: {e}", file=sys.stderr)
        return 1


def check_file(file_path: str) -> int:
    if not os.path.exists(file_path):
        print(f"Error: File '{file_path}' not found.", file=sys.stderr)
        return 1

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            source = f.read()

        lexer = Lexer(source, file_path=file_path)
        tokens = lexer.tokenize()

        parser = Parser(tokens)
        ast = parser.parse()

        analyzer = SemanticAnalyzer(file_path=file_path)
        analyzer.analyze(ast)

        print(f"Check successful: '{file_path}' has no syntax or semantic errors.")
        return 0

    except (LexerError, ParseError, SemanticError) as e:
        print(f"\n{e}", file=sys.stderr)
        return 1


def build_file(file_path: str, target: str = "vm", output_dir: Optional[str] = None) -> int:
    if not os.path.exists(file_path):
        print(f"Error: File '{file_path}' not found.", file=sys.stderr)
        return 1

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            source = f.read()

        lexer = Lexer(source, file_path=file_path)
        tokens = lexer.tokenize()

        parser = Parser(tokens)
        ast = parser.parse()

        analyzer = SemanticAnalyzer(file_path=file_path)
        analyzer.analyze(ast)

        ir_program = IRBuilder().build(ast)
        opt_ir = Optimizer().optimize(ir_program)

        serializer = BytecodeSerializer()
        compiled = serializer.compile_ir(opt_ir)

        base_name = os.path.splitext(os.path.basename(file_path))[0]

        if target == "windows":
            dist_dir = output_dir if output_dir else "dist"
            print(f"Building Windows native executable for '{file_path}'...")
            exe_path = build_windows_executable(compiled, base_name, dist_dir=dist_dir)
            print(f"Build successful: '{exe_path}'")
            return 0
        else:
            build_dir = output_dir if output_dir else "build"
            os.makedirs(build_dir, exist_ok=True)
            output_file = os.path.join(build_dir, f"{base_name}.pulsec")
            binary_data = serializer.serialize(compiled)

            with open(output_file, "wb") as f:
                f.write(binary_data)

            print(f"Build successful: '{output_file}'")
            return 0

    except (LexerError, ParseError, SemanticError) as e:
        print(f"\n{e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"\nBuild Error: {e}", file=sys.stderr)
        return 1


def main() -> None:
    parser = argparse.ArgumentParser(prog="pulse", description="The Pulse Programming Language CLI & Compiler")
    subparsers = parser.add_subparsers(dest="command", help="Available subcommands")

    # pulse run <file>
    run_cmd = subparsers.add_parser("run", help="Run a Pulse source (.pulse) or bytecode (.pulsec) file")
    run_cmd.add_argument("file", help="Path to file")

    # pulse check <file>
    check_cmd = subparsers.add_parser("check", help="Check a Pulse program file for syntax and semantic errors")
    check_cmd.add_argument("file", help="Path to .pulse source file")

    # pulse build <file> [--target vm|windows]
    build_cmd = subparsers.add_parser("build", help="Compile a Pulse program file into bytecode or executable")
    build_cmd.add_argument("file", help="Path to .pulse source file")
    build_cmd.add_argument("--target", choices=["vm", "windows"], default="vm", help="Build target (vm or windows)")
    build_cmd.add_argument("-o", "--output", help="Output directory")

    # pulse version
    subparsers.add_parser("version", help="Show Pulse language version")

    args = parser.parse_args()

    if args.command == "run":
        sys.exit(run_file(args.file))
    elif args.command == "check":
        sys.exit(check_file(args.file))
    elif args.command == "build":
        sys.exit(build_file(args.file, target=args.target, output_dir=args.output))
    elif args.command == "version":
        print(f"Pulse Language Compiler v{__version__}")
        sys.exit(0)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
