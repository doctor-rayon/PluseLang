import sys
import struct
from typing import List, Dict, Any, TextIO, Optional
from pulse.vm.opcodes import OpCode
from pulse.compiler.serializer import CompiledBytecode
from pulse.runtime.environment import Environment
from pulse.runtime.reactive_engine import ReactiveCycleError


class PulseVMError(Exception):
    def __init__(self, message: str, line: int = 1, column: int = 1, file_path: str = "<bytecode>"):
        super().__init__(f"PulseVMError in '{file_path}' at Line {line}, Column {column}: {message}")
        self.message = message
        self.line = line
        self.column = column
        self.file_path = file_path


class VMWatcher:
    def __init__(self, target_name: str, condition_code: bytes, body_code: bytes):
        self.target_name = target_name
        self.condition_code = condition_code
        self.body_code = body_code


class PulseVM:
    MAX_REACTION_DEPTH = 100

    def __init__(self, output_stream: TextIO = sys.stdout):
        self.output_stream = output_stream
        self.environment = Environment()
        self.operand_stack: List[Any] = []
        self.watchers: Dict[str, List[VMWatcher]] = {}
        self.reaction_depth = 0

    def run(self, compiled: CompiledBytecode, file_path: str = "<bytecode>") -> None:
        self.operand_stack = []
        self.environment = Environment()
        self.watchers = {}

        # Execute main code section
        self._execute_code(compiled.code, compiled, file_path)

    def _execute_code(self, code: bytes, compiled: CompiledBytecode, file_path: str) -> None:
        ip = 0
        code_len = len(code)

        while ip < code_len:
            current_ip = ip
            opcode = code[ip]
            ip += 1

            line, col = compiled.debug_map.get(current_ip, (1, 1))

            try:
                if opcode == OpCode.HALT:
                    break

                elif opcode == OpCode.PUSH_CONST:
                    const_idx = struct.unpack_from(">H", code, ip)[0]
                    ip += 2
                    self.operand_stack.append(compiled.constants[const_idx])

                elif opcode == OpCode.LOAD_VAR:
                    str_idx = struct.unpack_from(">H", code, ip)[0]
                    ip += 2
                    var_name = compiled.strings[str_idx]
                    val = self.environment.get(var_name, line, col)
                    self.operand_stack.append(val)

                elif opcode == OpCode.STORE_VAR:
                    str_idx = struct.unpack_from(">H", code, ip)[0]
                    ip += 2
                    var_name = compiled.strings[str_idx]
                    val = self.operand_stack.pop()
                    self.environment.define(var_name, val, is_state=False)

                elif opcode == OpCode.STATE_CREATE:
                    str_idx = struct.unpack_from(">H", code, ip)[0]
                    ip += 2
                    var_name = compiled.strings[str_idx]
                    val = self.operand_stack.pop()
                    self.environment.define(var_name, val, is_state=True)

                elif opcode == OpCode.STATE_GET:
                    str_idx = struct.unpack_from(">H", code, ip)[0]
                    ip += 2
                    var_name = compiled.strings[str_idx]
                    val = self.environment.get(var_name, line, col)
                    self.operand_stack.append(val)

                elif opcode == OpCode.STATE_SET:
                    str_idx = struct.unpack_from(">H", code, ip)[0]
                    ip += 2
                    var_name = compiled.strings[str_idx]
                    val = self.operand_stack.pop()
                    is_state = self.environment.assign(var_name, val, line, col)
                    if is_state:
                        self._notify_state_change(var_name, compiled, file_path, line, col)

                elif opcode == OpCode.WATCH_CREATE:
                    state_str_idx, watcher_idx = struct.unpack_from(">HH", code, ip)
                    ip += 4
                    state_name = compiled.strings[state_str_idx]
                    if watcher_idx < len(compiled.watchers):
                        w_info = compiled.watchers[watcher_idx]
                        vm_w = VMWatcher(
                            target_name=state_name,
                            condition_code=w_info["condition_code"],
                            body_code=w_info["body_code"]
                        )
                        if state_name not in self.watchers:
                            self.watchers[state_name] = []
                        self.watchers[state_name].append(vm_w)

                elif opcode == OpCode.ADD:
                    right = self.operand_stack.pop()
                    left = self.operand_stack.pop()
                    if isinstance(left, str) or isinstance(right, str):
                        self.operand_stack.append(self._stringify(left) + self._stringify(right))
                    else:
                        self.operand_stack.append(left + right)

                elif opcode == OpCode.SUB:
                    right = self.operand_stack.pop()
                    left = self.operand_stack.pop()
                    self.operand_stack.append(left - right)

                elif opcode == OpCode.MUL:
                    right = self.operand_stack.pop()
                    left = self.operand_stack.pop()
                    self.operand_stack.append(left * right)

                elif opcode == OpCode.DIV:
                    right = self.operand_stack.pop()
                    left = self.operand_stack.pop()
                    if right == 0:
                        raise PulseVMError("Division by zero.", line, col, file_path)
                    res = left / right if isinstance(left, float) or isinstance(right, float) else left // right
                    self.operand_stack.append(res)

                elif opcode == OpCode.MOD:
                    right = self.operand_stack.pop()
                    left = self.operand_stack.pop()
                    self.operand_stack.append(left % right)

                elif opcode == OpCode.EQ:
                    right = self.operand_stack.pop()
                    left = self.operand_stack.pop()
                    self.operand_stack.append(left == right)

                elif opcode == OpCode.NEQ:
                    right = self.operand_stack.pop()
                    left = self.operand_stack.pop()
                    self.operand_stack.append(left != right)

                elif opcode == OpCode.GT:
                    right = self.operand_stack.pop()
                    left = self.operand_stack.pop()
                    self.operand_stack.append(left > right)

                elif opcode == OpCode.GTE:
                    right = self.operand_stack.pop()
                    left = self.operand_stack.pop()
                    self.operand_stack.append(left >= right)

                elif opcode == OpCode.LT:
                    right = self.operand_stack.pop()
                    left = self.operand_stack.pop()
                    self.operand_stack.append(left < right)

                elif opcode == OpCode.LTE:
                    right = self.operand_stack.pop()
                    left = self.operand_stack.pop()
                    self.operand_stack.append(left <= right)

                elif opcode == OpCode.AND:
                    right = self.operand_stack.pop()
                    left = self.operand_stack.pop()
                    self.operand_stack.append(self._is_truthy(left) and self._is_truthy(right))

                elif opcode == OpCode.OR:
                    right = self.operand_stack.pop()
                    left = self.operand_stack.pop()
                    self.operand_stack.append(self._is_truthy(left) or self._is_truthy(right))

                elif opcode == OpCode.NOT:
                    val = self.operand_stack.pop()
                    self.operand_stack.append(not self._is_truthy(val))

                elif opcode == OpCode.NEG:
                    val = self.operand_stack.pop()
                    self.operand_stack.append(-val)

                elif opcode == OpCode.JUMP:
                    target_offset = struct.unpack_from(">I", code, ip)[0]
                    ip = target_offset

                elif opcode == OpCode.JUMP_IF_FALSE:
                    target_offset = struct.unpack_from(">I", code, ip)[0]
                    ip += 4
                    cond = self.operand_stack.pop()
                    if not self._is_truthy(cond):
                        ip = target_offset

                elif opcode == OpCode.PRINT:
                    val = self.operand_stack.pop()
                    self.output_stream.write(f"{self._stringify(val)}\n")
                    self.output_stream.flush()

                else:
                    raise PulseVMError(f"Unknown opcode 0x{opcode:02X}.", line, col, file_path)

            except PulseVMError:
                raise
            except ReactiveCycleError:
                raise
            except Exception as e:
                raise PulseVMError(str(e), line, col, file_path)

    def _notify_state_change(self, target_name: str, compiled: CompiledBytecode, file_path: str, line: int, col: int) -> None:
        if target_name not in self.watchers:
            return

        if self.reaction_depth >= self.MAX_REACTION_DEPTH:
            raise ReactiveCycleError(target_name, line=line, column=col)

        self.reaction_depth += 1
        try:
            for watcher in self.watchers[target_name]:
                # 1. Run condition code
                self._execute_code(watcher.condition_code, compiled, file_path)
                cond_val = self.operand_stack.pop() if self.operand_stack else False

                if self._is_truthy(cond_val):
                    # 2. Run body code
                    self._execute_code(watcher.body_code, compiled, file_path)
        finally:
            self.reaction_depth -= 1

    @staticmethod
    def _is_truthy(val: Any) -> bool:
        if val is None or val is False:
            return False
        if isinstance(val, (int, float)) and val == 0:
            return False
        if isinstance(val, str) and val == "":
            return False
        return True

    @staticmethod
    def _stringify(val: Any) -> str:
        if val is None:
            return "null"
        if isinstance(val, bool):
            return "true" if val else "false"
        if isinstance(val, float) and val.is_integer():
            return str(int(val))
        return str(val)
