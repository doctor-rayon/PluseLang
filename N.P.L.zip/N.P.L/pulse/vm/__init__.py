"""
Pulse Virtual Machine & Opcodes Module
"""

from .opcodes import OpCode

__all__ = ["OpCode"]
