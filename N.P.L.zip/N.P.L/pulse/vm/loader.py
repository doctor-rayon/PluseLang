from typing import Union
from pulse.compiler.serializer import BytecodeSerializer, CompiledBytecode


class BytecodeLoader:
    def __init__(self):
        self.serializer = BytecodeSerializer()

    def load_from_bytes(self, data: bytes) -> CompiledBytecode:
        return self.serializer.deserialize(data)

    def load_from_file(self, file_path: str) -> CompiledBytecode:
        with open(file_path, "rb") as f:
            data = f.read()
        return self.load_from_bytes(data)
