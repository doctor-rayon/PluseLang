from enum import IntEnum


class OpCode(IntEnum):
    PUSH_CONST     = 0x01  # arg: const_index (uint16)
    LOAD_VAR       = 0x02  # arg: str_index (uint16)
    STORE_VAR      = 0x03  # arg: str_index (uint16)
    STATE_CREATE   = 0x04  # arg: str_index (uint16)
    STATE_GET      = 0x05  # arg: str_index (uint16)
    STATE_SET      = 0x06  # arg: str_index (uint16)
    WATCH_CREATE   = 0x07  # arg: state_str_index (uint16), watcher_index (uint16)

    # Arithmetic & Logic
    ADD            = 0x10
    SUB            = 0x11
    MUL            = 0x12
    DIV            = 0x13
    MOD            = 0x14

    EQ             = 0x20
    NEQ            = 0x21
    GT             = 0x22
    GTE            = 0x23
    LT             = 0x24
    LTE            = 0x25
    AND            = 0x26
    OR             = 0x27
    NOT            = 0x28
    NEG            = 0x29

    # Control Flow
    JUMP           = 0x30  # arg: byte_offset (uint32)
    JUMP_IF_FALSE  = 0x31  # arg: byte_offset (uint32)

    # I/O & Lifecycle
    PRINT          = 0x40
    HALT           = 0xFF
