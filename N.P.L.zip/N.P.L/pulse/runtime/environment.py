from typing import Dict, Any, Optional
from dataclasses import dataclass


class RuntimeError(Exception):
    def __init__(self, message: str, line: int = 1, column: int = 1):
        super().__init__(f"RuntimeError at Line {line}, Column {column}: {message}")
        self.message = message
        self.line = line
        self.column = column


@dataclass
class VariableSlot:
    value: Any
    is_state: bool = False


class Environment:
    def __init__(self, parent: Optional['Environment'] = None):
        self.values: Dict[str, VariableSlot] = {}
        self.parent: Optional['Environment'] = parent

    def define(self, name: str, value: Any, is_state: bool = False) -> None:
        self.values[name] = VariableSlot(value=value, is_state=is_state)

    def get(self, name: str, line: int = 1, column: int = 1) -> Any:
        if name in self.values:
            return self.values[name].value
        if self.parent:
            return self.parent.get(name, line, column)
        raise RuntimeError(f"Undefined variable '{name}'.", line, column)

    def get_slot(self, name: str) -> Optional[VariableSlot]:
        if name in self.values:
            return self.values[name]
        if self.parent:
            return self.parent.get_slot(name)
        return None

    def assign(self, name: str, value: Any, line: int = 1, column: int = 1) -> bool:
        """Assigns a new value to an existing variable. Returns True if variable was state."""
        if name in self.values:
            slot = self.values[name]
            slot.value = value
            return slot.is_state
        if self.parent:
            return self.parent.assign(name, value, line, column)
        raise RuntimeError(f"Cannot assign to undefined variable '{name}'.", line, column)
