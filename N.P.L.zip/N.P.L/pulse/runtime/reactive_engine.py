from typing import Dict, List, TYPE_CHECKING
from pulse.parser.ast import WatchNode, WhenClauseNode

if TYPE_CHECKING:
    from .interpreter import Interpreter


class ReactiveCycleError(Exception):
    def __init__(self, target_name: str, line: int = 1, column: int = 1):
        super().__init__(
            f"ReactiveCycleError at Line {line}, Column {column}:\n"
            f"  Cascading state mutation cycle detected on state variable '{target_name}'. "
            f"Maximum reaction depth limit (100) exceeded."
        )
        self.target_name = target_name
        self.line = line
        self.column = column


class ReactiveEngine:
    MAX_REACTION_DEPTH = 100

    def __init__(self):
        # Maps state variable name -> list of registered WatchNode AST objects
        self.watchers: Dict[str, List[WatchNode]] = {}
        self.reaction_depth = 0

    def register_watch(self, target_name: str, watch_node: WatchNode) -> None:
        if target_name not in self.watchers:
            self.watchers[target_name] = []
        self.watchers[target_name].append(watch_node)

    def notify_change(self, target_name: str, interpreter: 'Interpreter') -> None:
        if target_name not in self.watchers:
            return

        if self.reaction_depth >= self.MAX_REACTION_DEPTH:
            raise ReactiveCycleError(target_name)

        self.reaction_depth += 1
        try:
            for watch_node in self.watchers[target_name]:
                for when_clause in watch_node.when_clauses:
                    # Evaluate when clause condition
                    cond_val = interpreter.evaluate(when_clause.condition)
                    if self._is_truthy(cond_val):
                        # Execute when clause body
                        interpreter.execute(when_clause.body)
        finally:
            self.reaction_depth -= 1

    @staticmethod
    def _is_truthy(val: any) -> bool:
        if val is None or val is False:
            return False
        if isinstance(val, (int, float)) and val == 0:
            return False
        if isinstance(val, str) and val == "":
            return False
        return True
