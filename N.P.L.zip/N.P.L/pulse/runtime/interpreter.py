import sys
from typing import Any, TextIO
from pulse.parser.ast import (
    ASTNode, ProgramNode, StatementNode, ExpressionNode,
    VarDeclNode, StateDeclNode, AssignmentNode, WatchNode, WhenClauseNode,
    BinaryOpNode, UnaryOpNode, LiteralNode, IdentifierNode, PrintStmtNode,
    BlockStmtNode, IfStmtNode, WhileStmtNode
)
from .environment import Environment, RuntimeError
from .reactive_engine import ReactiveEngine


class Interpreter:
    def __init__(self, output_stream: TextIO = sys.stdout):
        self.globals = Environment()
        self.environment = self.globals
        self.reactive_engine = ReactiveEngine()
        self.output_stream = output_stream

    def interpret(self, program: ProgramNode) -> None:
        for stmt in program.statements:
            self.execute(stmt)

    def execute(self, stmt: StatementNode) -> None:
        method_name = f"_exec_{stmt.__class__.__name__}"
        executor = getattr(self, method_name, self._generic_exec)
        executor(stmt)

    def evaluate(self, expr: ExpressionNode) -> Any:
        method_name = f"_eval_{expr.__class__.__name__}"
        evaluator = getattr(self, method_name, self._generic_eval)
        return evaluator(expr)

    def _generic_exec(self, node: ASTNode) -> None:
        raise RuntimeError(f"Unknown statement node '{node.__class__.__name__}'.", node.line, node.column)

    def _generic_eval(self, node: ASTNode) -> Any:
        raise RuntimeError(f"Unknown expression node '{node.__class__.__name__}'.", node.line, node.column)

    # --- Statement Executors ---

    def _exec_VarDeclNode(self, node: VarDeclNode) -> None:
        val = None
        if node.initializer:
            val = self.evaluate(node.initializer)
        self.environment.define(node.name, val, is_state=False)

    def _exec_StateDeclNode(self, node: StateDeclNode) -> None:
        val = None
        if node.initializer:
            val = self.evaluate(node.initializer)
        self.environment.define(node.name, val, is_state=True)

    def _exec_AssignmentNode(self, node: AssignmentNode) -> None:
        val = self.evaluate(node.value)
        is_state = self.environment.assign(node.name, val, node.line, node.column)
        if is_state:
            # Reassignment of state variable triggers reactive dispatch
            self.reactive_engine.notify_change(node.name, self)

    def _exec_WatchNode(self, node: WatchNode) -> None:
        self.reactive_engine.register_watch(node.target_name, node)

    def _exec_PrintStmtNode(self, node: PrintStmtNode) -> None:
        val = self.evaluate(node.expression)
        out_str = self._stringify(val)
        self.output_stream.write(f"{out_str}\n")
        self.output_stream.flush()

    def _exec_BlockStmtNode(self, node: BlockStmtNode) -> None:
        previous_env = self.environment
        try:
            self.environment = Environment(parent=previous_env)
            for stmt in node.statements:
                self.execute(stmt)
        finally:
            self.environment = previous_env

    def _exec_IfStmtNode(self, node: IfStmtNode) -> None:
        cond_val = self.evaluate(node.condition)
        if self._is_truthy(cond_val):
            self.execute(node.then_branch)
        elif node.else_branch:
            self.execute(node.else_branch)

    def _exec_WhileStmtNode(self, node: WhileStmtNode) -> None:
        while self._is_truthy(self.evaluate(node.condition)):
            self.execute(node.body)

    # --- Expression Evaluators ---

    def _eval_LiteralNode(self, node: LiteralNode) -> Any:
        return node.value

    def _eval_IdentifierNode(self, node: IdentifierNode) -> Any:
        return self.environment.get(node.name, node.line, node.column)

    def _eval_BinaryOpNode(self, node: BinaryOpNode) -> Any:
        left = self.evaluate(node.left)
        right = self.evaluate(node.right)
        op = node.operator

        if op == '+':
            if isinstance(left, str) or isinstance(right, str):
                return self._stringify(left) + self._stringify(right)
            return left + right
        elif op == '-':
            return left - right
        elif op == '*':
            return left * right
        elif op == '/':
            if right == 0:
                raise RuntimeError("Division by zero.", node.line, node.column)
            return left / right if isinstance(left, float) or isinstance(right, float) else left // right
        elif op == '%':
            return left % right
        elif op == '==':
            return left == right
        elif op == '!=':
            return left != right
        elif op == '>':
            return left > right
        elif op == '>=':
            return left >= right
        elif op == '<':
            return left < right
        elif op == '<=':
            return left <= right
        elif op == '&&':
            return self._is_truthy(left) and self._is_truthy(right)
        elif op == '||':
            return self._is_truthy(left) or self._is_truthy(right)

        raise RuntimeError(f"Unsupported binary operator '{op}'.", node.line, node.column)

    def _eval_UnaryOpNode(self, node: UnaryOpNode) -> Any:
        operand = self.evaluate(node.operand)
        if node.operator == '!':
            return not self._is_truthy(operand)
        elif node.operator == '-':
            return -operand
        raise RuntimeError(f"Unsupported unary operator '{node.operator}'.", node.line, node.column)

    @staticmethod
    def _is_truthy(val: Any) -> bool:
        if val is None or val is False:
            return False
        if isinstance(val, (int, float)) and val == 0:
            return False
        if isinstance(val, str) and val == "":
            return False
        return True

    @staticmethod
    def _stringify(val: Any) -> str:
        if val is None:
            return "null"
        if isinstance(val, bool):
            return "true" if val else "false"
        if isinstance(val, float) and val.is_integer():
            return str(int(val))
        return str(val)
